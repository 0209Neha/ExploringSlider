//
//  Customslider.m
//  ExploringSlider
//
//  Created by Neha Singh on 12/26/16.
//  Copyright © 2016 Neha Singh. All rights reserved.
//

#import "Customslider.h"

@interface ToolTipPopupView : UIView
@property (nonatomic) float value;
@property (nonatomic, retain) UIFont *fontSize;
@property (nonatomic, retain) NSString *toolTipValue;
@end

@implementation ToolTipPopupView

@synthesize value=_value;
@synthesize fontSize =_fontSize;
@synthesize toolTipValue = _toolTipValue;

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.fontSize = [UIFont boldSystemFontOfSize:18];
    }
    return self;
}

- (void)dealloc {
    self.toolTipValue = nil;
    self.fontSize = nil;
}

- (void)drawRect:(CGRect)rect {
    
    // Set the fill color
   [[UIColor colorWithRed:236.0f/256.0f green:236.0f/256.0f blue:236.0f/256.0f alpha:1] setFill];
    // Create the path for the rounded rectangle
    CGRect roundedRect = CGRectMake(self.bounds.origin.x, self.bounds.origin.y, self.bounds.size.width, self.bounds.size.height * 0.7);
    UIBezierPath *roundedRectPath = [UIBezierPath bezierPathWithRoundedRect:roundedRect cornerRadius:3.0];
    
    // Create the arrow path
    UIBezierPath *arrowPath = [UIBezierPath bezierPath];
    CGFloat midX = CGRectGetMidX(self.bounds);
    CGPoint p0 = CGPointMake(midX, CGRectGetMaxY(self.bounds));
    [arrowPath moveToPoint:p0];
    [arrowPath addLineToPoint:CGPointMake((midX - 10.0), CGRectGetMaxY(roundedRect))];
    [arrowPath addLineToPoint:CGPointMake((midX + 10.0), CGRectGetMaxY(roundedRect))];
    [arrowPath closePath];
    
    // Attach the arrow path to the rounded rectangle
    [roundedRectPath appendPath:arrowPath];
    
    [roundedRectPath fill];
    
    // Draw the text
    if (self.toolTipValue) {
       [[UIColor darkGrayColor] set];
        CGSize s = [_toolTipValue sizeWithAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor darkGrayColor], NSForegroundColorAttributeName,[UIFont fontWithName:@"American Typewriter" size:12], NSFontAttributeName, nil]];
        CGFloat yOffset = (roundedRect.size.height - s.height) / 2;
        CGRect textRect = CGRectMake(roundedRect.origin.x, yOffset, roundedRect.size.width, s.height);
        NSMutableParagraphStyle *theStyle = [NSMutableParagraphStyle new];
        [theStyle setLineBreakMode:NSLineBreakByWordWrapping];
        [theStyle setAlignment:NSTextAlignmentCenter];
        [_toolTipValue drawInRect:textRect withAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"American Typewriter" size:12], NSFontAttributeName,theStyle, NSParagraphStyleAttributeName, nil]];
    }
}

- (void)setValue:(float)aValue {
    _value = aValue;
    self.toolTipValue = [NSString stringWithFormat:@"%.2f", _value];
    [self setNeedsDisplay];
}

@end


@implementation Customslider

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(instancetype)init{
    self = [super init];
    if (self) {
        [self initToolTip];
    }
    return self;
}

-(CGRect)trackRectForBounds:(CGRect)bounds{
    _trackFrame = CGRectMake(16,(self.frame.size.height-3)/2,self.frame.size.width-39,3);
     return CGRectMake(16,(self.frame.size.height-3)/2,self.frame.size.width-39,3);
}
-(CGRect)minimumValueImageRectForBounds:(CGRect)bounds{
    return CGRectMake(0,(self.frame.size.height-15)/2,15,15);
}

-(CGRect)maximumValueImageRectForBounds:(CGRect)bounds{
    return CGRectMake(self.frame.size.width-20,(self.frame.size.height-20)/2, 20,20);
}

//- (CGRect)thumbRect {
//    CGRect thumbRct = [self thumbRectForBounds:self.bounds
//                                   trackRect:[self trackRectForBounds:self.bounds]
//                                       value:self.value];
//    return thumbRct;
//}

- (BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    // Fade in and update the tooltip view
    CGPoint touchPoint = [touch locationInView:self];
    // Check if the touch is withinh knob's boundary to show the tooltip-view
    if(CGRectContainsPoint([self thumbRectForBounds:self.bounds
                                          trackRect:[self trackRectForBounds:self.bounds]
                                              value:self.value], touchPoint)) {
        [self _positionAndUpdatePopupView];
        [self _fadePopupViewInAndOut:YES];
    }
    return [super beginTrackingWithTouch:touch withEvent:event];
}

- (BOOL)continueTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    // Update the popup view as slider knob is being moved
    [self _positionAndUpdatePopupView];
    return [super continueTrackingWithTouch:touch withEvent:event];
}

- (void)cancelTrackingWithEvent:(UIEvent *)event {
    [super cancelTrackingWithEvent:event];
}

- (void)endTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    // Fade out the popoup view
    [self _fadePopupViewInAndOut:NO];
    [super endTrackingWithTouch:touch withEvent:event];
}
- (void)initToolTip {
    toolTip = [[ToolTipPopupView alloc] initWithFrame:CGRectZero];
    toolTip.backgroundColor = [UIColor clearColor];
    toolTip.alpha = 0.0;
    [toolTip drawRect:CGRectZero];
    [self addSubview:toolTip];
}
- (void)_fadePopupViewInAndOut:(BOOL)aFadeIn {
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    if (aFadeIn) {
        toolTip.alpha = 1.0;
    } else {
        toolTip.alpha = 0.0;
    }
    [UIView commitAnimations];
}

- (void)_positionAndUpdatePopupView {
    CGRect _thumbRect = [self thumbRectForBounds:self.bounds
                                       trackRect:[self trackRectForBounds:self.bounds]
                                           value:self.value];
    CGRect popupRect = CGRectOffset(_thumbRect, 0, -(_thumbRect.size.height));
    toolTip.frame = CGRectInset(popupRect,0,0);
    toolTip.value = self.value;
    toolTip.toolTipValue = [NSString stringWithFormat:@"%d",(int)self.value];
}

-(UIView*)addTickMarksView
{
    [self initToolTip];
    // set up vars
    float x = _trackFrame.size.width ;
    float tickwidth = x / _noOfTicks;
    float xPos = self.trackFrame.origin.x;
    // initialize view to return
    UIView* tickview = [[UIView alloc]init];
    tickview.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y,
                            self.frame.size.width, self.frame.size.height);
    tickview.backgroundColor = [UIColor clearColor];
   // make a UIImageView with tick for each tick in the slider
    for (int i=0; i <= _noOfTicks; i++)
    {
        UIView *tick = [[UIView alloc] initWithFrame:CGRectMake(xPos,((self.frame.size.height - 10)/2),1, 10)];
        tick.backgroundColor = [UIColor colorWithWhite:0.7 alpha:1];
        tick.layer.shadowColor = [[UIColor whiteColor] CGColor];
        tick.layer.shadowOffset = CGSizeMake(0.0f, 1.0f);
        tick.layer.shadowOpacity = 1.0f;
        tick.layer.shadowRadius = 0.0f;
        [tickview insertSubview:tick belowSubview:self];
        xPos += (tickwidth );
    }
    return tickview;
}


@end
